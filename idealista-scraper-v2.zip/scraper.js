let descripcionTag = document.querySelector("div.adCommentsLanguage.expandable p");
let descripcionTexto = descripcionTag?.textContent.toLowerCase() || "";

if (
  descripcionTexto.includes("abstenerse") ||
  descripcionTexto.includes("agencias") ||
  descripcionTexto.includes("inmobiliaria") ||
  descripcionTexto.includes("inmobiliarias")
) {
  return "No quiere agencias";
}

let botonTelefono = document.querySelector(".hidden-contact-phones_text");
if (botonTelefono) {
  botonTelefono.click();
}

return new Promise((resolve) => {
  setTimeout(() => {
    if (!document.querySelector("div.professional-name span.particular")) {
      resolve("No es particular");
      return;
    }

    const datos = [];

    let daynow = new Date(Date.now()).toLocaleString();
    let daynowsplit = daynow.split(",");
    let daynowfecha = daynowsplit[0];

    let precio = document.querySelector("span.info-data-price span.txt-bold")?.textContent.trim() || "";
    let distrito = document.querySelector("span.main-info__title-minor")?.textContent.trim() || "";
    let direccion = document.querySelector("span.main-info__title-main")?.innerHTML.trim() || "";
    let direccionSplit = direccion.split(" ");
    let direccionTrim = direccionSplit.slice(4);
    let direccionParse = direccionTrim.join(',').replace(/,/g, ' ').split();
    let nombre = document.querySelector("div.professional-name span.particular input")?.value.trim() || "";

    let telefonoTag = document.querySelector("a.icon-phone-outline.hidden-contact-phones_formatted-phone._mobilePhone span.hidden-contact-phones_text");
    let telefono = telefonoTag ? telefonoTag.textContent.trim() : "N/A";

    let link = location.href;

    let infoSpans = document.querySelectorAll("div.info-features span");
    let metrosTrim = "";
    let caracteristica = "";
    let numHabitacion = 0;
    let planta = "";

    infoSpans.forEach((span) => {
      let text = span.textContent.toLowerCase();
      if (text.includes("m²")) {
        metrosTrim = text.split(" ")[0];
      } else if (text.includes("hab")) {
        numHabitacion = text.split(" ")[0];
      } else if (text.includes("planta")) {
        planta = text;
      } else {
        caracteristica = text;
      }
    });

    let fechaLlamada = "";
    let inicialLlamada = "";
    let fechaValoracion = "";
    let observaciones = "";
    let inicialLista = "RS";

    datos.push(
      daynowfecha,
      precio,
      distrito,
      direccionParse,
      nombre,
      telefono,
      link,
      metrosTrim,
      planta + " " + caracteristica,
      numHabitacion,
      fechaLlamada,
      inicialLlamada,
      fechaValoracion,
      observaciones,
      inicialLista
    );

    resolve(datos.join(";"));
  }, 5000); // aumentado a 5 segundos
});